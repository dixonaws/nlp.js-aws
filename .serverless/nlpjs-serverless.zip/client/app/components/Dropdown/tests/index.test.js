// import React from 'react';
// import { shallow } from 'enzyme';

// import Dropdown from '../index';

describe('<Dropdown />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
