// import React from 'react';
// import { shallow } from 'enzyme';

// import Table2Cell from '../index';

describe('<Table2Cell />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
