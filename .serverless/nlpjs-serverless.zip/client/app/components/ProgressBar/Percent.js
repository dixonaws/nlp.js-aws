import styled from 'styled-components';

export default styled.div`
  height: 2px;
  background: #29D;
  transition: all 300ms ease;
`;
