import { defineMessages } from 'react-intl';

export default defineMessages({
  agentDropDownDefault: {
    id: 'components.NavSideBar.create_domain.agent',
    defaultMessage: 'Select an Agent',
  },
});
