// import React from 'react';
// import { shallow } from 'enzyme';

// import SearchInput from '../index';

describe('<SearchInput />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
