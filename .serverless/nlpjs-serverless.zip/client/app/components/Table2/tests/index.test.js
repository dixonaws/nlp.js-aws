// import React from 'react';
// import { shallow } from 'enzyme';

// import Table2 from '../index';

describe('<Table2 />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
