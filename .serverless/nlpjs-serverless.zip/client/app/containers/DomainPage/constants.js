export const CHANGE_DOMAIN_DATA = 'DomainPage/CHANGE_DOMAIN_DATA';
export const RESET_DOMAIN_DATA = 'DomainPage/RESET_DOMAIN_DATA';
export const LOAD_DOMAIN = 'DomainPage/LOAD_DOMAIN';
export const LOAD_DOMAIN_SUCCESS = 'DomainPage/LOAD_DOMAIN_SUCCESS';
export const LOAD_DOMAIN_ERROR = 'DomainPage/LOAD_DOMAIN_ERROR';
